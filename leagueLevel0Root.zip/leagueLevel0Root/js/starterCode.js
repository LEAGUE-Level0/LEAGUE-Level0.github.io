function starterCode() {
var starter;

starter = document.getElementById("starterCode");

starter.innerHTML += "<h3>Starter code is provided in this module's Java project.</h3>";
  
}
