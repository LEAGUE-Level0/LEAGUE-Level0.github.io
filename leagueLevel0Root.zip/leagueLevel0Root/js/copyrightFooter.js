function copyright() {
    var footer;
    footer = document.getElementById("copyright");
    footer.innerHTML = 'Copyright <a href="http://www.jointheleague.org">League of Amazing Programmers</a> 2013-2017';
}
copyright();