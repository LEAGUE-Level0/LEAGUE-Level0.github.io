function module1code() {
var starter;

starter = document.getElementById("moduleLink");

starter.innerHTML += "<h3><a href=\"http://bit.ly/l0m1test\">Get module 1 Java project</a></h3>";
  
}
